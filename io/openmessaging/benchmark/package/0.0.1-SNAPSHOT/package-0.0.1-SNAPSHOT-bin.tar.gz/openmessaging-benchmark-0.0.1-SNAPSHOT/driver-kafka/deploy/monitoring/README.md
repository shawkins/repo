# Kafka dashboard for the Open Messaging Benchmark using the Prometheus/Grafana stack

- Builds a docker image
